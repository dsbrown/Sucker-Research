module.exports = require('./data.json');
