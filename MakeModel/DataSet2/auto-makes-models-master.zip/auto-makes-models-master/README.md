auto-makes-models
=================

Database for Vehicle Years, Makes, and Models from 1994 to present

I needed a database for user selection of years, makes, and models for vehicles 1994 to the present and could not find a clean list anywhere, so I making one.

Hopefully this will help anyone else in need of the same type data - or at least save someone a little time.

This work is licensed under a <a target="_blank" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License.</a>

NOTE
=================

I needed this data for a low to mid range estimation of used sales of vehicles in America, therefore the data does not include the following:

FORMULA CARS
CONCEPT CARS

LAMBORGHINI
LOTUS
PORCHE

ETA OF COMPLETION
=================
This project was started on May 20th and is scheduled to be complete by June 1st 2014.